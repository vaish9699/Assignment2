//required('dotenv').config();

const AWS = require('aws-sdk');

// Set the AWS Region
AWS.config.update({ region: 'ap-south-1' });

// Create DynamoDB service object
const dynamodb = new AWS.DynamoDB();

// Function to create tables
const createTables = async () => {
    try {
        // Define the q_Questions table
        const questionsTableParams = {
            TableName: 'q_Questions',
            KeySchema: [
                { AttributeName: 'questionId', KeyType: 'HASH' } // Partition key
            ],
            AttributeDefinitions: [
                { AttributeName: 'questionId', AttributeType: 'S' }, // String
                { AttributeName: 'topicId', AttributeType: 'S' }     // String
            ],
            GlobalSecondaryIndexes: [
                {
                    IndexName: 'TopicIndex',
                    KeySchema: [
                        { AttributeName: 'topicId', KeyType: 'HASH' }
                    ],
                    Projection: {
                        ProjectionType: 'ALL'
                    },
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 5,
                        WriteCapacityUnits: 5
                    }
                }
            ],
            ProvisionedThroughput: {
                ReadCapacityUnits: 5,
                WriteCapacityUnits: 5
            }
        };

        // Define the UserTestInstanceAnswer table
        const userTestInstanceTableParams = {
            TableName: 'UserTestInstanceAnswer',
            KeySchema: [
                { AttributeName: 'userId', KeyType: 'HASH' }, // Partition key
                { AttributeName: 'qId', KeyType: 'RANGE' }   // Sort key
            ],
            AttributeDefinitions: [
                { AttributeName: 'userId', AttributeType: 'S' }, // String
                { AttributeName: 'qId', AttributeType: 'S' },    // String
                { AttributeName: 'topicId', AttributeType: 'S' } // String
            ],
            GlobalSecondaryIndexes: [
                {
                    IndexName: 'TopicIndex',
                    KeySchema: [
                        { AttributeName: 'topicId', KeyType: 'HASH' }
                    ],
                    Projection: {
                        ProjectionType: 'ALL'
                    },
                    ProvisionedThroughput: {
                        ReadCapacityUnits: 5,
                        WriteCapacityUnits: 5
                    }
                }
            ],
            ProvisionedThroughput: {
                ReadCapacityUnits: 5,
                WriteCapacityUnits: 5
            }
        };

        // Create the q_Questions table
        console.log('Creating q_Questions table...');
        await dynamodb.createTable(questionsTableParams).promise();
        console.log('q_Questions table created successfully.');

        // Create the UserTestInstanceAnswer table
        console.log('Creating UserTestInstanceAnswer table...');
        await dynamodb.createTable(userTestInstanceTableParams).promise();
        console.log('UserTestInstanceAnswer table created successfully.');
    } catch (error) {
        console.error('Error creating tables:', error);
    }
};

// Execute the function
createTables();
