import axios from "axios";


// state: {
//     question: null,
//     userDetails: {},
//   },
  
//   mutations: {
//     SET_SCREEN2_DATA(state, questionData) {
//       state.question = questionData;
//     },
//     SET_USER_DETAILS(state, userDetails) {
//       state.userDetails = userDetails;
//     },
//   },
  
//   actions: {
//     async fetchScreen2Data({ commit, state }) {
//       try {
//         const response = await axios.post(
//           "https://4caeisr4q3.execute-api.us-east-1.amazonaws.com/dev/mentoapp/onboarding/domain",
//           { tempUserId: state.userDetails.tempUserId, selectedDomainId: state.selectedDomain },
//           { headers: { appflavour: "DEV", "Content-Type": "application/json" } }
//         );
//         commit("SET_SCREEN2_DATA", response.data[0]); // Assuming response contains question
//       } catch (error) {
//         console.error("Error fetching Screen 2 data:", error);
//       }
//     },
//     async submitUserDetails({ commit }, userDetails) {
//       try {
//         const response = await axios.post(
//           "https://4caeisr4q3.execute-api.us-east-1.amazonaws.com/dev/mentoapp/onboarding/login",
//           userDetails,
//           { headers: { appflavour: "DEV", "Content-Type": "application/json" } }
//         );
//         console.log("User details submitted successfully:", response.data);
//         commit("SET_USER_DETAILS", userDetails);
//       } catch (error) {
//         console.error("Error submitting user details:", error);
//       }
//     },
//   },
  






export default {
  namespaced: true,
  state: {
    timeOfDay: "",
    domainSelectionMessage: "",
    domains: [],
    selectedDomain: null,
    userDetails: {},
  },
  mutations: {
    SET_TIME_OF_DAY(state, time) {
      state.timeOfDay = time;
    },
    SET_SCREEN1_DATA(state, data) {
      state.domainSelectionMessage = data.domainSelectionMessage;
      state.domains = data.domains;
    },
  },
  actions: {
    determineTimeOfDay({ commit }) {
      const hours = new Date().getHours();
      const timeOfDay = hours >= 6 && hours < 18 ? "day" : "night";
      commit("SET_TIME_OF_DAY", timeOfDay);
    },
    async fetchScreen1Data({ commit }) {
      try {
        const response = await axios.post(
          "https://4caeisr4q3.execute-api.us-east-1.amazonaws.com/dev/mentoapp/onboarding/start",
          { newUser: true, deviceId: "sample-device-id" },
          { headers: { appflavour: "DEV", appVersion: "2.5.0", "Content-Type": "application/json" } }
        );
        commit("SET_SCREEN1_DATA", response.data);
      } catch (error) {
        console.error("Error fetching Screen 1 data:", error);
      }
    },
  },
};
