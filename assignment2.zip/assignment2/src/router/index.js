

export default router;
import Vue from "vue";
import VueRouter from "vue-router";
import Onboarding from "@/views/Onboarding.vue";

// Import views for each onboarding screen
import Screen1 from "@/components/Onboarding/Screen1.vue";
import Screen2 from "@/components/Onboarding/Screen2.vue";
import Screen3 from "@/components/Onboarding/Screen3.vue";
import FinalScreen from "@/components/Onboarding/FinalScreen.vue";

Vue.use(VueRouter);

const routes = [
  { path: "/", redirect: "/onboarding/screen1" },
  { path: "/onboarding", name: "Onboarding", component: Onboarding },
  { path: "/onboarding/screen1", name: "Screen1", component: Screen1 },
  { path: "/onboarding/screen2", name: "Screen2", component: Screen2 },
  { path: "/onboarding/screen3", name: "Screen3", component: Screen3 },
  { path: "/onboarding/final", name: "FinalScreen", component: FinalScreen },
];



const router = new VueRouter({
  mode: "history", // Optional: Enables cleaner URLs
  routes,
});

// export default router;


// import Vue from "vue";
// import VueRouter from "vue-router";
// import Onboarding from "@/views/Onboarding.vue";

// Vue.use(VueRouter);

// const routes = [
//   { path: "/onboarding", name: "Onboarding", component: Onboarding },
// ];

// export default new VueRouter({ mode: "history", routes });
