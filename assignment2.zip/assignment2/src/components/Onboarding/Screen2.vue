<template>
  <div>
    <Background :time="timeOfDay">
      <v-container>
        <h1>Answer the following question:</h1>
        <QuestionCard
          :question="question"
          @selectOption="handleOptionSelect"
        />
      </v-container>
    </Background>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Background from "@/components/Onboarding/Background.vue";
import QuestionCard from "@/components/Onboarding/QuestionCard.vue";

export default {
  components: { Background, QuestionCard },
  computed: mapState("onboarding", ["timeOfDay", "question"]),
  mounted() {
    this.fetchScreen2Data();
  },
  methods: {
    ...mapActions("onboarding", ["fetchScreen2Data", "submitOption"]),
    handleOptionSelect(optionId) {
      this.submitOption(optionId); // Save selected option
    },
  },
};
</script>
