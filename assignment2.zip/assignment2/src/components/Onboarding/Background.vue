<template>
  <div :class="backgroundClass">
    <slot /> <!-- Allows nested content to render -->
  </div>
</template>

<script>
export default {
  props: ["time"],
  computed: {
    backgroundClass() {
      return this.time === "day" ? "background-day" : "background-night";
    },
  },
};
</script>

<style scoped>
.background-day {
  background: url("@/assets/day-bg.jpg") no-repeat center center;
  background-size: cover;
  height: 100vh;
}

.background-night {
  background: url("@/assets/night-bg.jpg") no-repeat center center;
  background-size: cover;
  height: 100vh;
}
</style>
