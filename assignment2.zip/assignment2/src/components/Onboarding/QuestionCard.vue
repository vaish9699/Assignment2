<template>
  <v-card>
    <v-card-title>{{ question.questionText }}</v-card-title>
    <v-row>
      <v-col
        v-for="option in question.options"
        :key="option.optionId"
        cols="12" md="6"
      >
        <v-btn
          class="option-btn"
          block
          :ripple="true"
          @click="$emit('selectOption', option.optionId)"
        >
          <v-img :src="option.image" max-height="100px" />
          {{ option.text }}
        </v-btn>
      </v-col>
    </v-row>
  </v-card>
</template>

<script>
export default {
  props: ["question"],
};
</script>

<style scoped>
.option-btn {
  border: 1px solid #ddd;
  text-align: left;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
