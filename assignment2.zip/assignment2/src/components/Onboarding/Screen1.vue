<template>
  <div>
    <Background :time="timeOfDay" />
    <v-container>
      <h1>{{ domainSelectionMessage }}</h1>
      <v-row>
        <v-col
          v-for="domain in domains"
          :key="domain.domainId"
          cols="12" md="6"
        >
          <v-card>
            <v-img :src="domain.image" />
            <v-card-title>{{ domain.name }}</v-card-title>
            <v-card-subtitle>{{ domain.description }}</v-card-subtitle>
          </v-card>
        </v-col>
      </v-row>
    </v-container>
    <v-btn color="primary" @click="handleNext">Next</v-btn>

  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Background from "@/components/Onboarding/Background.vue";

export default {
  components: { Background },
  computed: mapState("onboarding", ["timeOfDay", "domainSelectionMessage", "domains"]),
  mounted() {
    this.fetchScreen1Data();
  },
  methods: mapActions("onboarding", ["fetchScreen1Data"]),
};
</script>

methods: {
  handleNext() {
    this.$router.push("/onboarding/screen2");
  },
},
