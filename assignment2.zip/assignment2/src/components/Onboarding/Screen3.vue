<template>
  <div>
    <Background :time="timeOfDay">
      <v-container>
        <h1>Tell us about yourself</h1>
        <v-form ref="form" v-model="valid">
          <v-text-field
            v-model="userDetails.name"
            label="Name"
            :rules="[rules.required]"
          />
          <v-text-field
            v-model="userDetails.phone"
            label="Phone Number"
            :rules="[rules.required, rules.phone]"
          />
          <v-btn :disabled="!valid" @click="submitDetails">Submit</v-btn>
        </v-form>
      </v-container>
    </Background>
  </div>
</template>

<script>
import { mapState, mapActions } from "vuex";
import Background from "@/components/Onboarding/Background.vue";

export default {
  components: { Background },
  data() {
    return {
      userDetails: { name: "", phone: "" },
      valid: false,
      rules: {
        required: value => !!value || "Required.",
        phone: value =>
          /^\d{10}$/.test(value) || "Phone must be 10 digits.",
      },
    };
  },
  computed: mapState("onboarding", ["timeOfDay"]),
  methods: {
    ...mapActions("onboarding", ["submitUserDetails"]),
    submitDetails() {
      this.submitUserDetails(this.userDetails);
    },
  },
};
</script>
